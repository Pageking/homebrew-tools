update_pixel() {
	echo "🔄 Updating Pixel..."
    brew update && brew upgrade pixel
}