#!/bin/bash
IFS=$'\n'
set -eou pipefail

source "${BREW_PREFIX}/libexec/lib/helpers/check-public-folder.sh"
source "${BREW_PREFIX}/libexec/lib/helpers/check-ssh-connection.sh"
source "${BREW_PREFIX}/libexec/lib/helpers/env/get-github-var.sh"
source "${BREW_PREFIX}/libexec/lib/helpers/env/set-github-var.sh"
source "${BREW_PREFIX}/libexec/lib/helpers/env/get-1pass-var.sh"
check_public_folder

# === CONFIGURATION ===
CONFIG_PATH="$HOME/.config/pixel/config.json"
SERVER=$(get_1pass_var "Servers" "PK1" "server")
DOMAIN=$(get_1pass_var "Servers" "PK1" "domain")
IP=$(get_1pass_var "Servers" "PK1" "ip")
WP_ADMIN=$(jq -r '.wp.admin_username' "$CONFIG_PATH")
WP_ADMIN_PASS=$(jq -r '.wp.admin_password' "$CONFIG_PATH")
WP_ADMIN_EMAIL=$(jq -r '.wp.admin_email' "$CONFIG_PATH")

WWW_ROOT=$(get_1pass_var "Servers" "PK1" "www_root")

PROJECT_NAME=$(get_github_var "PROJECT_NAME")
if [[ ! "$PROJECT_NAME" =~ ^[a-z0-9-]+$ ]]; then
  echo "Invalid project name. Use only lowercase letters, numbers, and hyphens (no spaces or special characters)."
  exit 1
fi

CORE_VERSION=$(get_github_var "CORE_VERSION")
if [[ -n "$CORE_VERSION" ]]; then
  echo "📌 Using core version '$CORE_VERSION' from GitHub variable..."
else
  echo "⚠️ No core version found in GitHub variable. You can set it using 'pixel set-core-version' command."
  exit 1
fi
DB_NAME="${PROJECT_NAME}"
DB_USER="${DB_NAME}_user"
DB_PASS="$(openssl rand -base64 12)"

GIT_REPO="git@github.com-info:$(jq -r '.github.org' "$CONFIG_PATH")/pk-theme.git"
TARGET_DIR="/var/www/vhosts/${PROJECT_NAME}.${DOMAIN}/${WWW_ROOT}/wp-content/themes"

SUFFIX=$(openssl rand -hex 5)
PLESK_USER="${DOMAIN}_${SUFFIX}"
PLESK_PASS=$(openssl rand -base64 16)

# === Save credentials in 1Password ===
OP_VAULT="Credentials"  # <-- Change to your actual vault name or ID
OP_ITEM_NAME="Plesk: ${PROJECT_NAME}.${DOMAIN}"
OP_ITEM_CREATED=false

cleanup_1pass_item() {
  if [[ "$OP_ITEM_CREATED" == true ]]; then
    echo "🧹 Removing 1Password item '$OP_ITEM_NAME' due to error..."
    op item delete "$OP_ITEM_NAME" --vault "$OP_VAULT" 2>/dev/null || true
  fi
}
trap cleanup_1pass_item ERR

# Check if item already exists
EXISTING_ITEM=$(op item list --vault "$OP_VAULT" --categories=Login --format=json | jq -r --arg name "$OP_ITEM_NAME" '.[] | select(.title == $name) | .id')

if [[ -n "$EXISTING_ITEM" ]]; then
  echo "⚠️ 1Password item already exists for $OP_ITEM_NAME. Skipping creation."
else
  echo "💾 Saving credentials to 1Password..."

  op item create \
    --vault "$OP_VAULT" \
    --category Login \
    "username=$PLESK_USER" \
    "password=$PLESK_PASS" \
    "url=https://${PROJECT_NAME}.${DOMAIN}" \
    "notes=Auto-generated on $(date)" \
    title="$OP_ITEM_NAME"

  OP_ITEM_CREATED=true
  echo "✅ Credentials saved to 1Password vault '$OP_VAULT' as '$OP_ITEM_NAME'"
fi

echo "👷 Creating domain on Plesk with project name '$PROJECT_NAME'"
check_ssh_connection "$SERVER"
ssh -o IgnoreUnknown=UseKeychain "$SERVER" bash <<EOF
# Exit on first failure
set -e 

# Creating Domain
plesk bin domain --create ${PROJECT_NAME}.${DOMAIN} -ip $IP -hosting true -www-root $WWW_ROOT -login $PLESK_USER -passwd $PLESK_PASS

# Enable SSH access
plesk bin subscription -u ${PROJECT_NAME}.${DOMAIN} -shell /bin/sh

# Create database
plesk bin database --create $DB_NAME -domain ${PROJECT_NAME}.${DOMAIN} -type mysql

# Create database user
plesk bin database --create-dbuser $DB_USER -passwd $DB_PASS -domain ${PROJECT_NAME}.${DOMAIN} -server localhost:3306 -database $DB_NAME

# Install WP
plesk ext wp-toolkit --install \
    -domain-name ${PROJECT_NAME}.${DOMAIN} \
    -installation-path /$WWW_ROOT \
    -admin-email $WP_ADMIN_EMAIL \
    -admin-user $WP_ADMIN \
    -admin-password $WP_ADMIN_PASS \
    -db-name $DB_NAME \
    -db-user $DB_USER \
    -db-password $DB_PASS

# Clone main theme into created domain
git clone -b $CORE_VERSION --recurse-submodules $GIT_REPO $TARGET_DIR/pk-theme

git clone -b test git@github.com-info:$(jq -r '.github.org' "$CONFIG_PATH")/${PROJECT_NAME}.git /var/www/vhosts/${PROJECT_NAME}.${DOMAIN}/httpdocs/wp-content/themes/$(jq -r '.github.template_repo' "$CONFIG_PATH")
EOF
echo "✅ Domain created"

if [[ -f "wp-cli.yml" ]]; then
	echo "🔄 Syncing wp-cli.yml to server..."
	scp wp-cli.yml "${SERVER}:/var/www/vhosts/${PROJECT_NAME}.${DOMAIN}/httpdocs/"
else 
	echo "⚠️ No wp-cli.yml file found in the current folder. Skipping wp-cli.yml upload."
fi

echo "🔄 Syncing wp-migrate-db-pro plugin to server..."
rsync -ravz --no-owner --no-group "wp-content/plugins/wp-migrate-db-pro/" "${SERVER}:/var/www/vhosts/${PROJECT_NAME}.${DOMAIN}/httpdocs/wp-content/plugins/wp-migrate-db-pro/"

echo "🔧 Fixing ownership of wp-migrate-db-pro to match the rest of the vhost..."
VHOST_ROOT="/var/www/vhosts/${PROJECT_NAME}.${DOMAIN}/httpdocs"
ssh -o IgnoreUnknown=UseKeychain "$SERVER" bash <<EOF
set -e
OWNER_GROUP=\$(stat -c '%U:%G' "${VHOST_ROOT}/wp-content")
chown -R "\$OWNER_GROUP" "${VHOST_ROOT}/wp-content/plugins/wp-migrate-db-pro"
EOF

# FIX: Change to 1Password dev team account
check_ssh_connection "${PLESK_USER}@${IP}" "$PLESK_PASS" 5 10
sshpass -p "${PLESK_PASS}" ssh -T -o IgnoreUnknown=UseKeychain -o PreferredAuthentications=password -o PubkeyAuthentication=no -o IdentitiesOnly=yes "${PLESK_USER}@${IP}" <<EOF
	set -e
	bash -lc '
		cd httpdocs
		wp user create support support@pageking.nl --user_pass="EQtyQAxpTNPEqLCqEs4epW9h" --role="administrator" --porcelain
		wp plugin activate wp-migrate-db-pro
	'
EOF

read -rp "Paste the wp-migrate-db-pro connection string: " migrate_connection_string
if [[ -z "$migrate_connection_string" ]]; then
	echo "⚠️ No connection string provided. Skipping GitHub secret update."
else
	# IDEA: paste this in the 1Pass credentials instead of GH var
	echo "💾 Saving connection string to GitHub secret..."
	set_github_var "WPM_TEST_CONNECTION_STRING" "$migrate_connection_string"
	echo "✅ Connection string saved to GitHub secret"
fi

read -rp "Do you want to sync the database/media/uploads to this test environment? [y/N]" sync_to_test
if [[ "$sync_to_test" =~ ^[Yy]$ ]]; then
	source "${BREW_PREFIX}/libexec/lib/helpers/test/sync-dev-to-test.sh"
	sync_dev_to_test
fi